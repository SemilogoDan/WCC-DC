function result=compensating(signal,CFO_est,T,time_acquisition,length_constant)
signal_rx=signal;

% adjust the length of signal_rx to ensure no error during reshape later
if  (length(signal_rx)-time_acquisition+1)>=length_constant
    signal_rx=signal_rx(1+length(signal_rx)-length_constant:end);
else
    signal_rx=signal_rx((end-length_constant+1):end);
end

% compensating the correspond CFO estimation
for j=1:length(signal_rx)
result(j)=signal_rx(j)*exp(1i*CFO_est*j*T);
end
end