function result=add_STO(signal_tx)

num_zero=10;
zero_delay=zeros(1,num_zero);
result=[zero_delay,signal_tx(1:end)];

end