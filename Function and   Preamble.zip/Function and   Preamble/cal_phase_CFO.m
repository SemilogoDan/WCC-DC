function result=cal_phase_CFO(signal,num_sub)

sum=0;
for column=1:(num_sub/8):num_sub
sum=signal(column)+sum;
end
result=sum/8;

end