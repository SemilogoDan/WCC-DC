function result=StoP_RemoveCP(signal_rx,m,n,length)

S2P_rx = reshape(signal_rx, m, n);
signal_rx_time_RCP = S2P_rx (length + 1:end,:);
result = fft(signal_rx_time_RCP,[],1);

end