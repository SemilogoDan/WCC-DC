function result=multipath_propagation(signal_tx,chtaps)
signal_tx=conv(signal_tx,chtaps);
result=signal_tx(1:end-length(chtaps)+1);
end