function result=mse_cal(tx,rx)
% calculate the MSE by the tx and rx
[column,row]=size(tx);
mse=0;
for i=1:column
    mse=abs((tx(i,1)-rx(i,1))^2)+mse;
end
result=1/column*mse;
end