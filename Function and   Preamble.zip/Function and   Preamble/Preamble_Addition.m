
clear; close all; clear all;
clc;
% ------------------- OFDM Communication Chain ----------------------------
%1.2_3
%% Initialization
SNR_list    = -10:20:30;       % SNR grid
Nbps        = 2;               % Number of bits per quam symbol
% OFDM parameters
B          = 100e6;            % Bandwidth
T=1/(B);
N_subcrr   = 1024;             % Number of subcarriers
Lcp        = 64;               % CP length, samples (TD)
preamble_L = 2;                % Preamble length, OFDM symbols (FD)
data_L     = 30;               % Data length in OFDM symbols (FD)
% number of OFDM symbols
f_dc       = 3.6e9;            % Carrier frequency 

% ------------------- OFDM Communication Chain ----------------------------
%% 1. QAM Modulation.
% Generate the stream of bits and map them into QAM symbols.
Nbits = data_L * N_subcrr * Nbps; %bits
bits = randi([0 1], [1 Nbits]);
bits_tx = bits' ;
 if(Nbps > 1)
     [symb_tx] = mapping(bits_tx,Nbps,'qam');
 else
    [symb_tx] = mapping(bits_tx,Nbps,'pam');
 end
 disp('Mapping done')

%% 2. OFDM Transmitter: 
S2P_tx = reshape(symb_tx,N_subcrr,data_L);%1024 x 300
%% Add the premble
load('preamble.mat');
preamble_tx=[preamble preamble];
S2P_tx=[preamble preamble S2P_tx];
%% Pilot addition
for i=3:(2+data_L)
    for j=1:128:1024
    S2P_tx(j,i)=1;
    end
end
%% IFFT
signal_tx_time = ifft(S2P_tx,[],1);
 
%% check the orthogonality among the sub-carriers
%signal_tx_time=[signal_tx_time(1,:); zeros(1023,300)];
%% Addition of CP
signal_tx_time_CP=signal_tx_time(end-(Lcp-1):end,:);
signal_tx_time_total=[signal_tx_time_CP;signal_tx_time];
%% Get the vector: signal_tx & The second propagation path
[m,n]=size(signal_tx_time_total);
mul_tx = m*n;
signal_tx =reshape(signal_tx_time_total,1, mul_tx );
length_constant=length(signal_tx);

chtaps = [1 0.1*randn(1)*exp(-1i*pi*randn(1))];
% chtaps = [1 0 0.4*exp(-1i*pi/8)];
% chtaps= [1 0 0];
equalization__chtaps= (fft(chtaps,N_subcrr))';
%% Multipath propagation
signal_tx=multipath_propagation(signal_tx,chtaps);
%% MRC
num_antennas=1;
for k = 1: length(SNR_list)
    if SNR_list(k)>=0
        SNR_list(k)=SNR_list(k)*num_antennas;
    else
        SNR_list(k)=SNR_list(k)/num_antennas;
    end
end
%% 3. Channel propagation:
% params.SNR_list = [20];
for k = 1: length(SNR_list)%------------------------------for loop
EbN0 = SNR_list(k);% SNR
energy_of_signal=1/B * trapz(abs(signal_tx).^2);
Eb = energy_of_signal / Nbits ;
N0 = Eb/10.^(EbN0/10);
NoisePower = 2*N0*B;
%signal_rx = simple_channel_AWGN(params,signal_tx,SNR,Nbits);
%% 4. OFDM Receiver:
% We implement the same as for the Transmitter but in a reversed order.
%% Add the uncertainty on time-of-arrival(STO) & Add noise
signal_STO=add_STO(signal_tx);
noise = sqrt(NoisePower/2)*(randn(length(signal_STO),1)+...
1i*randn(length(signal_STO),1))';
signal_STO_noise=signal_STO+noise;
%% CFO
signal_rx_STO_CFO=add_CFO(signal_STO_noise);
%% Auto-correlation for STO & CFO and compensating
[time_acquisition CFO_est]=auto_corr(signal_rx_STO_CFO);
CFO__est_list(k)=CFO_est;
%% SIMO
taps2 = [1 0.1*randn(1)*exp(-1i*pi*randn(1)) ];
taps3 = [1 0.1*randn(1)*exp(-1i*pi*randn(1)) ];
taps4 = [1 0.1*randn(1)*exp(-1i*pi*randn(1)) ];
%% SIMO
[equlization_RX2 time_acquisition_RX2 CFO_est_RX2]=SIMO(signal_tx,taps2,preamble_tx);
[equlization_RX3 time_acquisition_RX3 CFO_est_RX3]=SIMO(signal_tx,taps3,preamble_tx);
[equlization_RX4 time_acquisition_RX4 CFO_est_RX4]=SIMO(signal_tx,taps4,preamble_tx);
% take an average for equlization to use later
time_acquisition_total=[time_acquisition time_acquisition_RX2 time_acquisition_RX3 time_acquisition_RX4];
time_acquisition_mean=round(mean(time_acquisition_total));
CFO_est_total=[CFO_est CFO_est_RX2 CFO_est_RX3 CFO_est_RX4];
CFO_est_mean=mean(CFO_est_total);
%% compensating STO CFO
signal_rx=compensating(signal_rx_STO_CFO,CFO_est,T,time_acquisition,length_constant);
% signal_rx=compensating(signal_rx_STO_CFO,CFO_est,T,time_acquisition_mean,length_constant);
%% Serial to parallel & Remove of CP
signal_rx_fx=StoP_RemoveCP(signal_rx,m,n,Lcp);
%% Premble and get the channel impulse response
preamble_rx1 = signal_rx_fx(:,1);
preamble_rx2 = signal_rx_fx(:,2);
preamble_rx = [preamble_rx1 preamble_rx2];
CH_F = mean(preamble_rx./preamble_tx,2);
CH_T = ifft(CH_F);
CH_T = [CH_T(1:64);zeros((N_subcrr-Lcp),1)];
CH_F_t = fft(CH_T);
%% CH_F(Channel estimation in Freq domain)
equalization = CH_F;
signal_rx_est_freq=((signal_rx_fx)./(equalization));
signal_rx_fx=signal_rx_est_freq;
%% CH_T
equalization2= CH_F_t;
CIR=ifft(equalization2);% CIR(1:20)
figure;plot(abs(CIR));
%% MSE calculate
MSE_F(k)=mse_cal(equalization__chtaps,equalization);
MSE_T(k)=mse_cal(equalization__chtaps,equalization2);
%% Multiple Antennas(SIMO) part2
equalization_total=[equalization2 equlization_RX2 equlization_RX3 equlization_RX4];
equalization_mean=mean(equalization_total,2);
signal_rx_est_freq=((signal_rx_fx)./(equalization_mean));
signal_rx_fx=signal_rx_est_freq;
%% delete the preamble
signal_rx_fx=[signal_rx_fx(:,3:end)];
%% CFO tracking with Pilot 
for i=1:data_L
mean_phase=cal_phase_CFO(signal_rx_fx(:,i),N_subcrr);%30*1
signal_rx__fine_CFO(:,i)=signal_rx_fx(:,i)*conj(mean_phase);
end
%% Parallel to serial
[p, q] = size(signal_rx_fx);
mul_rx = p*q;
symb_rx = reshape (signal_rx_fx,mul_rx, 1);
%symb_rx = simple_ofdm_Rx(params,signal_rx,Nsymb_ofdm);
%% 5. Demodulation
     [bits_rx] = demapping(symb_rx,Nbps);
 disp('Demapping done')

%% Results
% Bit Error Rate:
bitErrorRate = sum(abs(bits_tx - bits_rx),'all') / length(bits_tx);
disp('$$ Displaying results:');
disp(['BER:', num2str(bitErrorRate)]);
BER_total(k)=bitErrorRate;

%%  We display the constalation Tx and Rx
figure;
subplot(1,2,1); plot(real(symb_tx),imag(symb_tx),'rx'); 
title('Tx qam constellation');grid on; axis([-2,2,-2,2]);pbaspect([1 1 1])
subplot(1,2,2); plot(real(symb_rx),imag(symb_rx),'.'); 
title('Rx qam constellation');grid on; axis([-2,2,-2,2]);pbaspect([1 1 1])
end
close all;
figure;
semilogy(BER_total,'-x');
ylim([10^(-4) 10^(0)]);
hold on;
% title('Bit error rate by the channel estimation in freq-dom');
title('Bit error rate by the channel estimation in time-dom');
% title(['Bit error rate with length of cp is ',num2str(params.Lcp),' & data is ',num2str(params.data_L)]);
grid on;
xlabel('Varying SNR');
ylabel('Bit error rate');
%% MSE figure for channel estimation accuracy as function of SNR
figure;
plot(MSE_F,'-x');
hold on 
plot(MSE_T,'-x');
title('MSE comparision');ylabel('MSE');xlabel('list for a varying SNR');
legend('MSE in freq domain','MSE in time domain')
